import React, { useState, useEffect, useMemo } from 'react';
import { db, auth } from '../firebase';
import { 
  collection, query, where, getDocs, addDoc, 
  serverTimestamp, deleteDoc, doc, writeBatch 
} from 'firebase/firestore';
import { jsPDF } from "jspdf";
import autoTable from 'jspdf-autotable';
import JSZip from "jszip";
import { saveAs } from "file-saver";
import { 
  TrendingDown, FileText, Trash2, UploadCloud, History, 
  CheckCircle, AlertTriangle, Archive, Download, Undo2, 
  Calculator, Wallet, Search, RefreshCcw, BarChart3, Receipt,
  Database, Upload
} from 'lucide-react';

import { 
  Page, Card, KpiCard, DataTable, Btn, 
  Badge, Input, Select, Tabs, StatRow 
} from '../components/ui';
import { colors, moeda, data as formatData } from '../globalStyles';

export default function DesencaixeSupervisor({ userData }) {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('Lançamentos');
  const [cities, setCities] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [cycles, setCycles] = useState([]);
  
  const [form, setForm] = useState({ 
    description: '', amount: '', date: new Date().toISOString().split('T')[0], 
    storeId: '', category: '', supplier: '', recibo: ''
  });
  const [comprovanteBase64, setComprovanteBase64] = useState(null);
  const [conferencia, setConferencia] = useState({ systemValue: '', cashValue: '' });

  const categories = ['Luz', 'Água', 'Limpeza', 'Manutenção', 'Marketing', 'Bonificação', 'Material Técnico', 'Combustível', 'Outros'];

useEffect(() => {
    const loadInitialData = async () => {
      // Verificação rigorosa: Só prossegue se userData e clusterId existirem
      if (!userData?.clusterId) {
        console.warn("Aguardando clusterId do usuário...");
        return;
      }
      
      try {
        // Busca cidades do cluster para o select
        const qCities = query(
          collection(db, "cities"), 
          where("clusterId", "==", userData.clusterId)
        );
        const snapCities = await getDocs(qCities);
        setCities(snapCities.docs.map(d => ({ id: d.id, ...d.data() })));
        
        // Só chama as despesas após garantir que temos o auth
        if (auth.currentUser?.uid) {
          fetchExpenses();
        }
      } catch (err) { 
        console.error("Erro ao carregar cidades:", err); 
      }
    };
    
    loadInitialData();
  }, [userData]);

  const fetchExpenses = async () => {
    // Verifica se o usuário está logado para evitar erro no 'where'
    if (!auth.currentUser?.uid) return;

    setLoading(true);
    try {
      // Notas Abertas
      const qExp = query(collection(db, "petty_cash"), 
        where("supervisorId", "==", auth.currentUser.uid), 
        where("status", "==", "open")
      );
      const snapExp = await getDocs(qExp);
      setExpenses(snapExp.docs.map(d => ({ id: d.id, ...d.data() })));

      const qCycles = query(collection(db, "petty_cash_cycles"), 
        where("supervisorId", "==", auth.currentUser.uid)
      );
      const snapCycles = await getDocs(qCycles);
      setCycles(snapCycles.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => b.closedAt - a.closedAt));
    } catch (err) { 
      console.error("Erro ao buscar despesas:", err); 
    }
    setLoading(false);
  };

  const totalDespesas = useMemo(() => expenses.reduce((acc, curr) => acc + parseFloat(curr.amount || 0), 0), [expenses]);
  const totalHistorico = useMemo(() => cycles.reduce((acc, curr) => acc + (curr.totalExpenses || 0), 0), [cycles]);

  const diffConferencia = useMemo(() => {
    const sistema = parseFloat(conferencia.systemValue) || 0;
    const fisico = parseFloat(conferencia.cashValue) || 0;
    return (fisico + totalDespesas) - sistema;
  }, [conferencia, totalDespesas]);

  // ── FUNÇÕES DE BACKUP (JSON) ──
  const exportarBackupJSON = () => {
    const backupData = {
      tipo: "BACKUP_DESENCAIXE_OQUEI",
      dataExportacao: new Date().toISOString(),
      supervisor: userData.name,
      dados: {
        expenses,
        cycles
      }
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: "application/json" });
    saveAs(blob, `Backup_Desencaixe_${userData.name.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.json`);
  };

  const importarBackupJSON = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target.result);
        if (json.tipo !== "BACKUP_DESENCAIXE_OQUEI") throw new Error("Arquivo de backup inválido.");

        const confirmar = window.confirm(`ATENÇÃO: Você está prestes a importar ${json.dados.expenses.length} notas e ${json.dados.cycles.length} ciclos de histórico. Os dados serão ADICIONADOS ao banco atual. Continuar?`);
        
        if (confirmar) {
          setLoading(true);
          const batch = writeBatch(db);

          // Importar Notas Abertas
          json.dados.expenses.forEach(item => {
            const newRef = doc(collection(db, "petty_cash"));
            const { id, ...dataToSave } = item; // Remove ID antigo
            batch.set(newRef, { ...dataToSave, supervisorId: auth.currentUser.uid, status: 'open' });
          });

          // Importar Ciclos
          json.dados.cycles.forEach(item => {
            const newRef = doc(collection(db, "petty_cash_cycles"));
            const { id, ...dataToSave } = item;
            batch.set(newRef, { ...dataToSave, supervisorId: auth.currentUser.uid });
          });

          await batch.commit();
          alert("Backup restaurado com sucesso!");
          fetchExpenses();
        }
      } catch (err) {
        alert("Erro ao importar: " + err.message);
      } finally {
        setLoading(false);
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // Limpa o input
  };

  // ── OUTROS HANDLERS (MANTIDOS) ──
  const handleAddExpense = async (e) => {
    e.preventDefault();
    if (!form.storeId) return alert("Selecione a loja.");
    setLoading(true);
    try {
      await addDoc(collection(db, "petty_cash"), {
        ...form,
        amount: parseFloat(form.amount),
        storeName: form.storeId === 'Geral' ? 'Geral' : cities.find(c => c.id === form.storeId)?.name || 'Geral',
        supervisorId: auth.currentUser.uid,
        status: 'open',
        comprovante: comprovanteBase64,
        createdAt: serverTimestamp()
      });
      setForm({ ...form, description: '', amount: '', category: '', supplier: '', recibo: '' });
      setComprovanteBase64(null);
      fetchExpenses();
    } catch (err) { alert(err.message); }
    setLoading(false);
  };

  const handleCloseCycle = async () => {
    if (!window.confirm("Deseja fechar o caixa e arquivar este ciclo?")) return;
    setLoading(true);
    try {
      const batch = writeBatch(db);
      const cycleRef = doc(collection(db, "petty_cash_cycles"));
      batch.set(cycleRef, {
        supervisorId: auth.currentUser.uid,
        supervisorName: userData.name,
        closedAt: new Date(),
        totalExpenses: totalDespesas,
        systemBalance: parseFloat(conferencia.systemValue),
        physicalCash: parseFloat(conferencia.cashValue),
        difference: diffConferencia,
        itemCount: expenses.length,
        itemsSnapshot: expenses
      });
      expenses.forEach(exp => batch.update(doc(db, "petty_cash", exp.id), { status: 'closed', cycleId: cycleRef.id }));
      await batch.commit();
      setConferencia({ systemValue: '', cashValue: '' });
      fetchExpenses();
      setActiveTab('Histórico');
    } catch (err) { alert(err.message); }
    setLoading(false);
  };

  const handleRevertCycle = async (cycle) => {
    if (!window.confirm("ESTORNO: As notas voltarão para a tela de lançamentos e o registro do histórico será excluído. Continuar?")) return;
    setLoading(true);
    try {
      const batch = writeBatch(db);
      cycle.itemsSnapshot.forEach(item => batch.update(doc(db, "petty_cash", item.id), { status: 'open', cycleId: null }));
      batch.delete(doc(db, "petty_cash_cycles", cycle.id));
      await batch.commit();
      fetchExpenses();
      setActiveTab('Lançamentos');
    } catch (err) { alert(err.message); }
    setLoading(false);
  };

  const handleDownloadZIP = async (lista, filename) => {
    const zip = new JSZip();
    const folder = zip.folder("Comprovantes");
    const docPdf = new jsPDF();
    docPdf.text("Relatório de Desencaixe", 14, 20);
    autoTable(docPdf, {
      startY: 30,
      head: [['Data', 'Fornecedor', 'Descrição', 'Valor']],
      body: lista.map(e => [formatData(e.date), e.supplier || e.fornecedor, e.description, moeda(e.amount)]),
      headStyles: { fillColor: [5, 150, 105] }
    });
    zip.file(`Relatorio_Baixa.pdf`, docPdf.output('blob'));
    lista.forEach((exp) => {
      if (exp.comprovante) {
        const base64 = exp.comprovante.split(',')[1];
        const ext = exp.comprovante.includes("pdf") ? "pdf" : "jpg";
        const nome = `${exp.date}_${exp.supplier || exp.fornecedor}_${exp.recibo || 'SN'}`.replace(/[^a-zA-Z0-9]/g, '_');
        folder.file(`${nome}.${ext}`, base64, {base64: true});
      }
    });
    const content = await zip.generateAsync({type:"blob"});
    saveAs(content, `${filename}.zip`);
  };

  return (
    <Page title="Desencaixe de Loja" subtitle="Gestão financeira, conferência e backups.">
      <Tabs 
        tabs={['Lançamentos', 'Conferência', 'Histórico', 'Backup']} 
        active={activeTab} 
        onChange={setActiveTab} 
      />

      {/* --- ABA LANÇAMENTOS --- */}
      {activeTab === 'Lançamentos' && (
        <div className="animated-view">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '25px' }}>
            <KpiCard label="Despesas no Ciclo" valor={moeda(totalDespesas)} icon={<TrendingDown size={22}/>} accent={colors.danger} />
            <KpiCard label="Notas pendentes" valor={expenses.length} icon={<FileText size={22}/>} accent={colors.primary} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '25px', alignItems: 'start' }}>
            <Card title="Novo Registro">
              <form onSubmit={handleAddExpense} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                <Input label="Valor da Nota (R$)" type="number" step="0.01" value={form.amount} onChange={e => setForm({...form, amount: e.target.value})} required />
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                  <Input label="Data" type="date" value={form.date} onChange={e => setForm({...form, date: e.target.value})} required />
                  <Input label="Nº Recibo/NF" placeholder="Ex: 5412" value={form.recibo} onChange={e => setForm({...form, recibo: e.target.value})} />
                </div>
                <Input label="Fornecedor" placeholder="Quem recebeu?" value={form.supplier} onChange={e => setForm({...form, supplier: e.target.value})} required />
                <Input label="Descrição" placeholder="Ex: Tonner para Impressora" value={form.description} onChange={e => setForm({...form, description: e.target.value})} required />
                <Select label="Loja" value={form.storeId} onChange={e => setForm({...form, storeId: e.target.value})} options={[{value: 'Geral', label: 'Geral/Cluster'}, ...cities.map(c => ({value: c.id, label: c.name}))]} required />
                <div style={{ border: '2px dashed var(--border)', padding: '15px', borderRadius: '12px', textAlign: 'center' }}>
                  <input type="file" id="up" hidden onChange={(e) => {
                    const reader = new FileReader();
                    reader.onloadend = () => setComprovanteBase64(reader.result);
                    reader.readAsDataURL(e.target.files[0]);
                  }} accept="image/*,application/pdf" />
                  <label htmlFor="up" style={{ cursor: 'pointer', color: 'var(--text-muted)', fontSize: '13px' }}>
                    <UploadCloud size={20} /> {comprovanteBase64 ? "Nota Anexada ✅" : "Anexar Comprovante"}
                  </label>
                </div>
                <Btn type="submit" loading={loading} style={{ width: '100%' }}>Lançar Despesa</Btn>
              </form>
            </Card>

            <Card title="Notas em Aberto" actions={<Btn variant="secondary" size="sm" onClick={() => handleDownloadZIP(expenses, 'Pack_Atual')}><Archive size={14}/> ZIP das Notas</Btn>}>
              <DataTable 
                columns={[
                  { key: 'date', label: 'Data', render: (v) => formatData(v) },
                  { key: 'supplier', label: 'Fornecedor' },
                  { key: 'amount', label: 'Valor', render: (v) => <b style={{color:colors.danger}}>-{moeda(v)}</b> },
                  { key: 'comprovante', label: 'Anexo', render: (v) => v ? <Badge cor="success">Sim</Badge> : <Badge cor="warning">Não</Badge> },
                  { key: 'actions', label: '', align: 'right', render: (_, row) => <Btn variant="ghost" onClick={() => deleteDoc(doc(db, 'petty_cash', row.id)).then(fetchExpenses)}><Trash2 size={14} color={colors.danger}/></Btn> }
                ]} 
                data={expenses} 
              />
            </Card>
          </div>
        </div>
      )}

      {/* --- ABA CONFERÊNCIA --- */}
      {activeTab === 'Conferência' && (
        <div className="animated-view" style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '25px' }}>
          <Card title="Resumo do Ajuste" accent={colors.primary}>
             <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div style={{ background: 'var(--bg-app)', padding: '25px', borderRadius: '20px', border: '1px solid var(--border)' }}>
                   <StatRow label="(-) Total de Despesas (Notas)" value={moeda(totalDespesas)} color={colors.danger} />
                </div>
                <div style={{ 
                  textAlign: 'center', padding: '40px', borderRadius: '24px', flex: 1,
                  background: conferencia.systemValue ? (diffConferencia === 0 ? `${colors.success}10` : `${colors.danger}05`) : 'var(--bg-panel)',
                  border: `2px dashed ${conferencia.systemValue ? (diffConferencia === 0 ? colors.success : colors.danger) : 'var(--border)'}40`,
                  display: 'flex', flexDirection: 'column', justifyContent: 'center'
                }}>
                  <p style={{fontSize:'12px', fontWeight:'bold', color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'1px'}}>Diferença Final Apurada</p>
                  <h1 style={{fontSize: '56px', fontWeight: '900', color: conferencia.systemValue ? (diffConferencia === 0 ? colors.success : colors.danger) : 'var(--text-muted)', margin: '10px 0'}}>{moeda(diffConferencia)}</h1>
                  {conferencia.systemValue && <Badge cor={diffConferencia === 0 ? "success" : "danger"} style={{ alignSelf: 'center' }}>{diffConferencia === 0 ? "Caixa Batido!" : "Diferença no Caixa"}</Badge>}
                </div>
             </div>
          </Card>

          <Card title="Informar Valores">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <Input label="1. Saldo no Sistema (Centralizador)" type="number" icon={<Calculator size={18}/>} value={conferencia.systemValue} onChange={e => setConferencia({...conferencia, systemValue: e.target.value})} />
              <Input label="2. Dinheiro Físico em Mãos" type="number" icon={<Wallet size={18}/>} value={conferencia.cashValue} onChange={e => setConferencia({...conferencia, cashValue: e.target.value})} />
              <Btn style={{ width: '100%', height: '56px' }} onClick={handleCloseCycle} disabled={!conferencia.systemValue || loading}><CheckCircle size={20} style={{marginRight: '10px'}}/> Encerrar e Arquivar Ciclo</Btn>
            </div>
          </Card>
        </div>
      )}

      {/* --- ABA HISTÓRICO --- */}
      {activeTab === 'Histórico' && (
        <div className="animated-view" style={{ display: 'flex', flexDirection: 'column', gap: '25px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px' }}>
            <KpiCard label="Total Acumulado" valor={moeda(totalHistorico)} icon={<BarChart3 size={22}/>} accent={colors.success} />
            <KpiCard label="Ciclos Fechados" valor={cycles.length} icon={<History size={22}/>} accent={colors.info} />
          </div>

          <Card title="Ciclos de Caixa Anteriores">
            <DataTable 
              columns={[
                { key: 'closedAt', label: 'Data Fechamento', render: (v) => formatData(v?.toDate ? v.toDate() : v) },
                { key: 'itemCount', label: 'Notas', render: (v) => <span style={{fontWeight:'800'}}>{v} itens</span> },
                { key: 'totalExpenses', label: 'Soma das Notas', render: (v) => moeda(v) },
                { key: 'difference', label: 'Diferença', render: (v) => <Badge cor={v === 0 ? 'success' : 'danger'}>{moeda(v)}</Badge> },
                { key: 'actions', label: 'Ações', align: 'right', render: (_, row) => (
                  <div style={{display:'flex', gap:'8px', justifyContent:'flex-end'}}>
                    <Btn variant="secondary" size="sm" onClick={() => handleDownloadZIP(row.itemsSnapshot, 'Arquivo_Caixa')}><Download size={16}/></Btn>
                    <Btn variant="ghost" size="sm" onClick={() => handleRevertCycle(row)}><Undo2 size={16} color={colors.warning}/></Btn>
                  </div>
                )}
              ]}
              data={cycles}
              loading={loading}
            />
          </Card>
        </div>
      )}

      {/* --- ABA BACKUP (NOVA) --- */}
      {activeTab === 'Backup' && (
        <div className="animated-view" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '25px' }}>
          <Card title="Exportar Banco de Dados" accent={colors.primary}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center', textAlign: 'center', padding: '20px' }}>
               <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: `${colors.primary}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.primary }}>
                 <Download size={32} />
               </div>
               <div>
                 <h3 style={{ margin: '0 0 10px 0', color: 'var(--text-main)' }}>Baixar Backup (.json)</h3>
                 <p style={{ fontSize: '13px', color: 'var(--text-muted)', lineHeight: '1.5' }}>
                   Gere um arquivo contendo todos os lançamentos em aberto e o histórico de ciclos fechados. 
                   Útil para auditoria externa ou migração de conta.
                 </p>
               </div>
               <Btn onClick={exportarBackupJSON} style={{ width: '100%' }}>
                 <Database size={18} style={{marginRight: '10px'}}/> Gerar Arquivo de Backup
               </Btn>
            </div>
          </Card>

          <Card title="Restaurar Banco de Dados" accent={colors.warning}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center', textAlign: 'center', padding: '20px' }}>
               <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: `${colors.warning}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.warning }}>
                 <Upload size={32} />
               </div>
               <div>
                 <h3 style={{ margin: '0 0 10px 0', color: 'var(--text-main)' }}>Importar Arquivo</h3>
                 <p style={{ fontSize: '13px', color: 'var(--text-muted)', lineHeight: '1.5' }}>
                   Selecione um arquivo .json gerado anteriormente por este sistema. 
                   <br/><b style={{color: colors.danger}}>Atenção:</b> Os dados importados serão adicionados ao banco de dados atual.
                 </p>
               </div>
               <label style={{ width: '100%' }}>
                 <input type="file" accept=".json" hidden onChange={importarBackupJSON} />
                 <div style={{ ...global.btnSecondary, height: '45px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
                   <FileText size={18} /> Selecionar Backup
                 </div>
               </label>
            </div>
          </Card>
        </div>
      )}
    </Page>
  );
}